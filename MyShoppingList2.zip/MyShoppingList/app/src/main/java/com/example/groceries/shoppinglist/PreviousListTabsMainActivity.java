package com.example.groceries.shoppinglist;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import com.example.groceries.shoppinglist.adapters.TabsPagerAdapter;

/**
 * Contains logic to set swipe able tabs with view pager
 * */

public class PreviousListTabsMainActivity extends AppCompatActivity {

    //This is our viewPager
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragments_main);


        String[] tabs={getString(R.string.tab_daily),getString(R.string.tab_week),getString(R.string.tab_monthly)};
        //Creating our pager adapter
        TabsPagerAdapter adapter = new TabsPagerAdapter(getSupportFragmentManager(), tabs.length);

        //Initializing the tabLayout
        TabLayout tabLayout = findViewById(R.id.tabLayout);

        tabLayout.setupWithViewPager(viewPager);

        //Initializing viewPager
        viewPager = findViewById(R.id.pager);

        //Adding the tabs using addTab() method
        for(String tab:tabs){

            tabLayout.addTab(tabLayout.newTab().setText(tab));
        }
        //Adding adapter to pager
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        //Adding onTabSelectedListener to swipe views
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
}
