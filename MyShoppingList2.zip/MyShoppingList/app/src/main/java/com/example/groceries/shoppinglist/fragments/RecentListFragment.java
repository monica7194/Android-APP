package com.example.groceries.shoppinglist.fragments;

import android.app.Dialog;
import android.app.Fragment;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.groceries.shoppinglist.R;
import com.example.groceries.shoppinglist.adapters.ShoppingListDbAdapter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static android.graphics.Color.TRANSPARENT;

/**
 * Contains logic to display recent list table data,update recent table list data and
 * calculate total of item prices and remove existing file with latest file on completion of calculation
 * */

public class RecentListFragment extends Fragment implements AdapterView.OnItemLongClickListener {

    private ListView todayListView;
    private Button buttonSave;
    private TextView totalText;

    private String curDate;
    private ArrayList<String> itemNames,quantityList, pricesList;

    private int position;
    private ShoppingListDbAdapter dbAdapter;
    private Cursor cursor;
    private int k=0;
    private double price;

    private RecentItemsListAdapter listAdapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //inflating fragment layout
        View rootView = inflater.inflate(R.layout.fragment_recent_list, container, false);

        //getting references of fragment view's
        todayListView=rootView.findViewById(R.id.list_todays);
        buttonSave=rootView.findViewById(R.id.btn_save_list);
        Button buttonCalculateList = rootView.findViewById(R.id.btn_calculate_list);
        totalText=rootView.findViewById(R.id.textview_total);

        dbAdapter=new ShoppingListDbAdapter(getActivity());//creating data base object
        dbAdapter.open();
        cursor=dbAdapter.getWeeklyItems();

        //array list's for storing data
        itemNames=new ArrayList<>();
        quantityList=new ArrayList<>();
        pricesList=new ArrayList<>();

        long msTime = System.currentTimeMillis();
        Date curDateTime = new Date(msTime);

        SimpleDateFormat formatter = new SimpleDateFormat("dd'-'MMM'-'yyyy");
        curDate = formatter.format(curDateTime);

        if (cursor.getCount()!=0){
            cursor.moveToFirst();
            updateListItems();
        }

        todayListView.setOnItemLongClickListener(this);

        buttonCalculateList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//button to calculate total of items price
                price=0;
                k=0;

                for (int i=0;i<pricesList.size();i++) {

                    if (k<pricesList.size()){

                        price = price + Double.parseDouble(pricesList.get(k));

                        k++;
                    }
                }
                totalText.setVisibility(View.VISIBLE);
                totalText.setText("Total :"+price);
            }
        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//save button will visible if you change after calculated price

                saveState(curDate);//to save items as file in the storage with current date

                buttonSave.setVisibility(View.GONE);
            }
        });

        return rootView;
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        this.position=position;
        return false;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getActivity().getMenuInflater().inflate(R.menu.context_menu_delete,menu);
    }

    @Override
    public boolean onContextItemSelected(final MenuItem item) {

        switch (item.getItemId()){
            case R.id.context_remove://to remove item from list

                cursor.moveToPosition(position);
                String rowId = cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_WEEK_ID));
                dbAdapter.deleteWeeklyItem(rowId);
                listAdapter.notifyDataSetChanged();
                updateListItems();

                break;
            case R.id.context_edit://to edit or update item details

                cursor.moveToPosition(position);

                final String id = cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_WEEK_ID));
                dbAdapter.getWeeklyItem(id);

                final String iPrice = cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_WEEK_ITEM_PRICE));

                //update dialog creation
                final Dialog updateDialog = new Dialog(getActivity());
                updateDialog.setTitle("Items List :");
                updateDialog.setContentView(R.layout.update_item_dialog);
                updateDialog.show();

                updateDialog.getWindow().setBackgroundDrawable(new ColorDrawable(TRANSPARENT));

                final EditText updateEdt = updateDialog.findViewById(R.id.edt_update_item);
                final EditText updateQty= updateDialog.findViewById(R.id.edt_update_qty);
                final EditText updatePrice=updateDialog.findViewById(R.id.edt_update_price);

                Button updateButton = updateDialog.findViewById(R.id.btn_update);
                Button cancelButton = updateDialog.findViewById(R.id.btn_cancel);

                updateEdt.setVisibility(View.GONE);
                updateQty.setVisibility(View.GONE);
                updatePrice.setText(iPrice);

                updateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        dbAdapter.modifyWeeklyItem(id,updatePrice.getText().toString());

                        updateListItems();

                        buttonSave.setVisibility(View.VISIBLE);
                        updateDialog.dismiss();
                        toast(getString(R.string.price_updated));
                    }
                });

                cancelButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        updateDialog.dismiss();
                    }
                });

                break;

        }
        return super.onContextItemSelected(item);
    }

    //Updating the displaying data
    private void updateListItems(){

        itemNames.clear();
        quantityList.clear();
        pricesList.clear();

        cursor=dbAdapter.getWeeklyItems();

            for (int i=0;i<cursor.getCount();i++){
                cursor.moveToPosition(i);
                itemNames.add(cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_WEEK_ITEM)));
                quantityList.add(cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_WEEK_QTY)));
                pricesList.add(cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_WEEK_ITEM_PRICE)));
            }

        listAdapter=new RecentItemsListAdapter();
        listAdapter.notifyDataSetChanged();

        todayListView.setAdapter(listAdapter);
    }
    //custom toast creation
    private void toast(String msg){

        //Inflating Custom Toast Layout
        LayoutInflater inflaters =  getActivity().getLayoutInflater();
        View layout = inflaters.inflate(R.layout.toast_layout,
                (ViewGroup) getActivity().findViewById(R.id.toast_layout_root));

        TextView text = layout.findViewById(R.id.text);

        text.setText(msg);
        Toast toast = new Toast(getContext());
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.show();
    }
    //Adapter class contains listView data with custom list layout
    private class RecentItemsListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            // return the all items count
            return cursor.getCount();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            // Inflating custom layout to display items list
            View view = convertView;
            LayoutInflater inflater= getActivity().getLayoutInflater();
            view=inflater.inflate(R.layout.recent_list_data, null);

            // Calling view references
            TextView titleText = view.findViewById(R.id.text_title);
            TextView edtQuantity=view.findViewById(R.id.text_qty);
            EditText edtItemPrice=view.findViewById(R.id.edt_price);

            registerForContextMenu(edtItemPrice);

            String singleItem=itemNames.get(position);

            titleText.setText(singleItem);

            edtQuantity.setText(quantityList.get(position));

            edtItemPrice.setText(pricesList.get(position));

            Animation anim = AnimationUtils.loadAnimation(getActivity(), R.anim.fly_in_from_top_corner);
            view.setAnimation(anim);
            anim.start();

            return view;
        }
    }

    //Saving bought items list as file in the storage
    private void saveState(String titleDate) {

        String fileName=titleDate;

        try {
            File root = new File(Environment.getExternalStorageDirectory() +
                    File.separator + "Shopping List" + File.separator + "Data");
            if (!root.exists()) {
                root.mkdirs();
            }

            File gpxFile = new File(root, fileName+".txt");

            // if file doesn't exists, then create it
            if (gpxFile.exists()) {
                gpxFile.delete();
            }
            gpxFile.createNewFile();
                FileWriter fw = new FileWriter(gpxFile.getAbsoluteFile());

                for (int i=0;i<itemNames.size();i++){
                    String body = itemNames.get(i)+"@t"+quantityList.get(i)+"@s"+pricesList.get(i)+"@t";

                    fw.write(body);
                    fw.flush();
                }
            fw.close();
            toast(getString(R.string.saved));

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
