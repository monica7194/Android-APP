package com.example.groceries.shoppinglist.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.groceries.shoppinglist.DataViewActivity;
import com.example.groceries.shoppinglist.R;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Contains logic to display current week and previous week list files and
 * launching DataView activity
 * */

public class WeeklyDataFragment extends Fragment {

    private Button btnPrevious,btnNext;
    private ListView weekDaysListView;
    private ArrayList<String> days,allItemDate;
    private TextView txtDate;
    private WeekListAdapter adapter;

    private int longPosition, listTitlePosition;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_monthly_data, container, false);
        //getting views reference's
        weekDaysListView = rootView.findViewById(R.id.listview_month);
        btnNext = rootView.findViewById(R.id.btn_present_month);
        btnPrevious = rootView.findViewById(R.id.btn_prev_month);
        txtDate = rootView.findViewById(R.id.txt_month);

        btnNext.setEnabled(false);

        days=new ArrayList();
        allItemDate = new ArrayList();

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR,0);
        SimpleDateFormat sdf = new SimpleDateFormat("dd'-'MMM'-'yyyy");//changing format of date
        days.clear();

        for (int i = 7; i > 0; i--) {//getting current week dates
            days.add(sdf.format(cal.getTime()));
            cal.add(Calendar.DAY_OF_WEEK, -1);
        }

        txtDate.setText(days.get(0)+"\t to \t"+days.get(days.size()-1));


        fillData();//calling to get available files in the week

        btnPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//to move previous week


                btnPrevious.setEnabled(false);
                btnNext.setEnabled(true);

                days.clear();
                Calendar cal = Calendar.getInstance();

                cal.add(Calendar.DAY_OF_YEAR, -7);

                // Date format
                String strDateFormat = "dd'-'MMM'-'yyyy";
                SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);

                for (int i=0;i<7;i++){//getting previous week dates
                    days.add(sdf.format(cal.getTime()));

                    cal.add(Calendar.DAY_OF_YEAR, -1);
                }

                txtDate.setText(days.get(0)+"\t to \t"+days.get(days.size()-1));
                allItemDate.clear();
                fillData();

            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//to move current week

                btnPrevious.setEnabled(true);
                btnNext.setEnabled(false);

                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DAY_OF_YEAR,0);
                SimpleDateFormat sdf = new SimpleDateFormat("dd'-'MMM'-'yyyy");//changing format of date
                days.clear();

                for (int i = 7; i > 0; i--) {//getting current week dates
                    //Log.i("dateTag", sdf.format(cal.getTime()));
                    days.add(sdf.format(cal.getTime()));
                    cal.add(Calendar.DAY_OF_YEAR,-1);
                }

                txtDate.setText(days.get(0)+"\t to \t"+days.get(days.size()-1));
                allItemDate.clear();
                fillData();

            }
        });

        //launching DataView activity on list item click
        weekDaysListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                listTitlePosition = i;

                Intent intent = new Intent(getActivity(), DataViewActivity.class);
                intent.putExtra("title", allItemDate.get(i));
                startActivity(intent);
            }
        });

        weekDaysListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                longPosition = i;

                return false;
            }
        });

        return rootView;
    }

    //getting stored file's of shopping list
    private void fillData() {
        allItemDate.clear();
        File file = new File(Environment.getExternalStorageDirectory() +
                File.separator + "Shopping List" + File.separator + "Data");
        String arr[] = file.list();

        if (arr != null) {
            for (String i : arr) {
                if (i.endsWith(".txt")) {
                    String[] splitedShortDescription = i.split(".txt");
                    for (String date:days){
                        if (splitedShortDescription[0].equals(date)){
                            // Setting data to the TextViews
                            allItemDate.add(splitedShortDescription[0]);
                        }
                    }
                }
            }
        }else {
            allItemDate.add("No data to display");
        }
        adapter=new WeekListAdapter();
        adapter.notifyDataSetChanged();

        weekDaysListView.setAdapter(adapter);
    }

    //Adapter class contains listView data with custom list layout
    private class WeekListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return allItemDate.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {

            final LayoutInflater inflater= getActivity().getLayoutInflater();
            view=inflater.inflate(R.layout.swiping_tabs_data, null);

            adapter.notifyDataSetChanged();
            // Calling view references
            TextView titleTextView = view.findViewById(R.id.text_item);

            String title= allItemDate.get(position);

            titleTextView.setText(title);

            //applying animation to display list items
            Animation anim = AnimationUtils.loadAnimation(getActivity(), R.anim.fly_in_from_top_corner);
            view.setAnimation(anim);
            anim.start();

            return view;
        }
    }

}
