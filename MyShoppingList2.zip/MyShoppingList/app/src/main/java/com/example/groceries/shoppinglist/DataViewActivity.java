package com.example.groceries.shoppinglist;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/***
 * Contains logic to open a file based intent extra value
 * */

public class DataViewActivity extends AppCompatActivity {

    private TextView fileNameText,totalText;
    private String text,splitedTitle;
    private ArrayList fileItems,evenItems,itemsQtyList,itemsPriceList;
    public String titles;

    private double dbPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_view);

        //getting view references
        ListView dataListView = findViewById(R.id.listview_dataview);
        fileNameText=findViewById(R.id.text_file_title);
        totalText=findViewById(R.id.textView_total);

        //array list to store data
        fileItems=new ArrayList();
        evenItems=new ArrayList();
        itemsQtyList=new ArrayList();
        itemsPriceList=new ArrayList();

        //getting extra values to open a particular file
        Intent intent=getIntent();
        titles = intent.getStringExtra("title");
        if (!titles.endsWith(".txt")){
            titles=titles+".txt";
        }

        splitedTitle=titles.split(".txt")[0];

        openFile(titles);//calling to open file

        DataViewAdapter dataViewAdapter = new DataViewAdapter();
        dataListView.setAdapter(dataViewAdapter);

    }

    //Method to open a file based on the title
    private void openFile(String title) {

        fileNameText.setText(splitedTitle);

        try {
            File sdcard = new File(Environment.getExternalStorageDirectory() +
                    File.separator + "Shopping List" + File.separator + "Data");
            File file1 = new File(sdcard,title);

            BufferedReader br = new BufferedReader(new FileReader(file1));
            String line;
            while ((line = br.readLine()) != null) {
                text=line;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try{

            String[] data = text.split("@t");

            for (String w: data){
                fileItems.add(w.trim());
            }


        }catch (Exception e){


        }


        for (int i=0;i<fileItems.size();i++){
            if (i%2==0){
                evenItems.add(fileItems.get(i));
            }else {

                String qtyPrices = fileItems.get(i).toString();

                String[] tempQty = qtyPrices.split("@s");

                itemsQtyList.add(tempQty[0]);
                itemsPriceList.add(tempQty[1]);

                dbPrice=dbPrice+Double.parseDouble(tempQty[1]);

            }
        }
        totalText.setText("Total : "+dbPrice);

    }
//Adapter class contains listView data with custom list layout
    private class DataViewAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return evenItems.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int pos, View view, ViewGroup viewGroup) {

            LayoutInflater inflater=getLayoutInflater();

            view=inflater.inflate(R.layout.completed_items_row,null);

            // Calling view references
            TextView itemNameText = view.findViewById(R.id.txt_itemName);
            TextView itemsQtyText = view.findViewById(R.id.txt_itemQty);
            EditText itemPrice = view.findViewById(R.id.edt_itemPrice);

            itemPrice.setFocusable(false);

            itemNameText.setText(evenItems.get(pos).toString());
            itemsQtyText.setText(itemsQtyList.get(pos).toString());
            itemPrice.setText(itemsPriceList.get(pos).toString());

            return view;
        }
    }
}
