package com.example.groceries.shoppinglist.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.groceries.shoppinglist.DataViewActivity;
import com.example.groceries.shoppinglist.R;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Contains logic to display all list files which are stored in the storage and
 * launching DataView activity
 * */

public class DailyListItemsFragment extends Fragment {

    private ListView allItemsListView;
    private ArrayList allItemDate;
    private AllListAdapter allListAdapater;
    private static final int DELETE_ID = Menu.FIRST;
    private int longPosition;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        //inflating fragment layout
        View rootView = inflater.inflate(R.layout.daily_list_data, container, false);

        allItemsListView = rootView.findViewById(R.id.listview_alllists);

        allItemDate = new ArrayList();

        fillData();//calling to get available files

        registerForContextMenu(allItemsListView);//registering for context menu

        //launching DataView activity on list item click
        allItemsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(getActivity(), DataViewActivity.class);
                intent.putExtra("title",allItemDate.get(i).toString());
                startActivity(intent);

            }
        });

        allItemsListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                longPosition = i;

                return false;
            }
        });
        return rootView;
    }

    //method to get all available shopping list files
    private void fillData() {

        File file = new File(Environment.getExternalStorageDirectory() +
                File.separator + "Shopping List" + File.separator + "Data");
        String arr[] = file.list();

        allItemDate.clear();


        try {
            if (arr == null) {
                allItemDate.add("No files to display");
            } else {
                for (String i : arr) {
                    if (i.endsWith(".txt")) {
                        allItemDate.add(i);
                    }
                }
            }
        }

        catch (Exception e)
        {

        }

        allListAdapater = new AllListAdapter();
        allListAdapater.notifyDataSetChanged();

        allItemsListView.setAdapter(allListAdapater);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0, DELETE_ID, 0, "Delete");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case DELETE_ID://to delete file from storage

                String currentData = allItemDate.get(longPosition).toString();

                try {
                    File sdcard = new File(Environment.getExternalStorageDirectory() +
                            File.separator + "Shopping List" + File.separator + "Data");
                    File file1 = new File(sdcard, currentData);
                    file1.getCanonicalFile().delete();
                    fillData();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        return super.onContextItemSelected(item);
    }

    //Adapter class contains listView data with custom list layout
    private class AllListAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return allItemDate.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {

            final LayoutInflater inflater= getActivity().getLayoutInflater();
            view=inflater.inflate(R.layout.swiping_tabs_data, null);

            allListAdapater.notifyDataSetChanged();
            // Calling view references
            TextView titleTextView = view.findViewById(R.id.text_item);

            String title=allItemDate.get(position).toString();

            String[] splitedShortDescription = title.split(".txt");

            // Setting data to the TextViews
            titleTextView.setText(splitedShortDescription[0]);

            //applying animation to display list items
            Animation anim = AnimationUtils.loadAnimation(getActivity(), R.anim.fly_in_from_top_corner);
            view.setAnimation(anim);
            anim.start();

            return view;
        }
    }
}
