package com.example.groceries.shoppinglist;

import android.Manifest;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.example.groceries.shoppinglist.fragments.AddShoppingListFragment;
import com.example.groceries.shoppinglist.fragments.RecentListFragment;

/* This is first screen
   * Handles setting of list items fragment,recent list fragment and launching previous list
   */

public class HomeActivity extends AppCompatActivity
		implements NavigationView.OnNavigationItemSelectedListener {


	private static final int REQUEST_WRITE_STORAGE = 112;

	private LinearLayout shoppingLinear,recentLinear,avbLinear;
	private FragmentManager fm;
	private TextView titleText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);

		DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
		ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
				this, drawer, toolbar, R.string.drawer_open, R.string.drawer_close);
		drawer.addDrawerListener(toggle);
		toggle.syncState();

		NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
		navigationView.setNavigationItemSelectedListener(this);
		//Loading Permissions into an array
		String[] PERMISSIONS = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
				Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA,
				Manifest.permission.INTERNET, Manifest.permission.ACCESS_NETWORK_STATE
		};

        /*checking whether the permissions are granted or not
        * If not requesting for permissions
        * */
		if (!hasPermissions(this, PERMISSIONS)) {
			ActivityCompat.requestPermissions(this, PERMISSIONS, REQUEST_WRITE_STORAGE);
		}

		fm=getFragmentManager();//getting fragment manager

		//getting views reference id's
		recentLinear=findViewById(R.id.linear_today_list);
		shoppingLinear=findViewById(R.id.linear_shopping_list);
		avbLinear=findViewById(R.id.linear_day_list);
		titleText=findViewById(R.id.textView_head);

		recentLinear.setBackgroundColor(Color.TRANSPARENT);
		avbLinear.setBackgroundColor(Color.TRANSPARENT);

		shoppingLinear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				fragmentChanger(new AddShoppingListFragment());//setting AddShoppingListFragment

				titleText.setText(getString(R.string.list_items));//setting title as current fragment name
				recentLinear.setBackgroundColor(Color.TRANSPARENT);
				avbLinear.setBackgroundColor(Color.TRANSPARENT);
				shoppingLinear.setBackground(getResources().getDrawable(R.drawable.bg_layout));
			}
		});

		recentLinear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				fragmentChanger(new RecentListFragment());//setting RecentListFragment

				titleText.setText(getString(R.string.recent_list));
				recentLinear.setBackground(getResources().getDrawable(R.drawable.bg_layout));
				shoppingLinear.setBackgroundColor(Color.TRANSPARENT);
				avbLinear.setBackgroundColor(Color.TRANSPARENT);
			}
		});

		avbLinear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {//launching PreviousLists activity
				startActivity(new Intent(HomeActivity.this,PreviousListTabsMainActivity.class));
			}
		});

		FragmentTransaction ft1 = fm.beginTransaction();//Start a series of edit operations on the Fragments associated with this FragmentManager
		ft1.add(R.id.frame_fragment, new AddShoppingListFragment());//adding fragment to FragmentTransaction
		ft1.commit();

	}

	//Method to change fragments dynamically
	private void fragmentChanger(Fragment fragment){
		FragmentTransaction ft = fm.beginTransaction();
		ft.setCustomAnimations(R.animator.fragment_slide_left_enter,//applying animation to play while replacing fragment
				R.animator.fragment_slide_left_exit,
				R.animator.fragment_slide_right_enter,
				R.animator.fragment_slide_right_exit);
		ft.replace(R.id.frame_fragment, fragment);//to replace fragment

		ft.addToBackStack(null);
		ft.commit();
	}


	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		switch (requestCode) {
			case REQUEST_WRITE_STORAGE: {
				if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
					//reload my activity with permission granted or use the features what required the permission
				} else {
					//Inflating Custom Toast Layout
					LayoutInflater inflater = getLayoutInflater();
					View layout = inflater.inflate(R.layout.toast_layout,
							(ViewGroup) findViewById(R.id.toast_layout_root));

					TextView text =  layout.findViewById(R.id.text);

					text.setText(getString(R.string.permission_required));
					Toast toast = new Toast(getApplicationContext());
					toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
					toast.setDuration(Toast.LENGTH_SHORT);
					toast.setView(layout);
					toast.show();
				}
			}
		}
	}

	//getting call if permissions are not granted
	public static boolean hasPermissions(Context context, String... permissions) {
		//checking the Android version 6.0 or not
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
			for (String permission : permissions) {
				if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public void onBackPressed() {


		finish();

		super.onBackPressed();
	}

	@SuppressWarnings("StatementWithEmptyBody")
	@Override
	public boolean onNavigationItemSelected(MenuItem item) {
		// Handle navigation view item clicks here.
		int id = item.getItemId();

		if (id == R.id.nav_home) {
			// Handle the camera action
		} /*else if (id == R.id.nav_share) {

			Intent share = new Intent(Intent.ACTION_SEND);
			share.setType("text/*");

			share.putExtra(Intent.EXTRA_TITLE, getResources().getString(R.string.app_name));

			share.putExtra(
					Intent.EXTRA_TEXT,
					getResources().getString(R.string.app_name)
							+ "\n"
							+ "https://play.google.com/store/apps/details?id=" + getPackageName());

			startActivity(Intent.createChooser(share, "share"));

		} else if (id == R.id.nav_rate) {

			Intent intent = new Intent(
					Intent.ACTION_VIEW,
					Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName()));
			startActivity(intent);

		} else if (id == R.id.nav_moreapps) {

			Intent intent = new Intent(HomeActivity.this,MoreAppsActivity.class);
			startActivity(intent);

		}*/

		DrawerLayout drawer =  findViewById(R.id.drawer_layout);
		drawer.closeDrawer(GravityCompat.START);
		return true;
	}
}
