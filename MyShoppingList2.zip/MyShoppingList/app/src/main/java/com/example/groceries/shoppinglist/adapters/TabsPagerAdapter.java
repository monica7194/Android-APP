package com.example.groceries.shoppinglist.adapters;


import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.example.groceries.shoppinglist.fragments.DailyListItemsFragment;
import com.example.groceries.shoppinglist.fragments.MonthlyDataFragment;
import com.example.groceries.shoppinglist.fragments.WeeklyDataFragment;


/**
 * Contains logic to change fragments based position
 */

public class TabsPagerAdapter extends FragmentStatePagerAdapter {

    //integer to count number of tabs
    private int tabCount;

    //Constructor to the class
    public TabsPagerAdapter(FragmentManager fm, int tabCount) {
        super(fm);
        //Initializing tab count
        this.tabCount= tabCount;
    }

    //Overriding method getItem
    @Override
    public Fragment getItem(int position) {
        //Returning the current tabs
        switch (position) {
            case 0:
                return new DailyListItemsFragment();
            case 1:
                return new WeeklyDataFragment();
            case 2:
                return new MonthlyDataFragment();
            default:
                return null;
        }
    }

    //Overridden method getCount to get the number of tabs
    @Override
    public int getCount() {
        return tabCount;
    }
}
