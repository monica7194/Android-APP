package com.example.groceries.shoppinglist.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.groceries.shoppinglist.DataViewActivity;
import com.example.groceries.shoppinglist.R;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Contains logic to display current month and previous month list files and
 * launching DataView activity
 * */

public class MonthlyDataFragment extends Fragment {

    private ListView monthListView;
    private Button btnLastMonth,btnCurrentMonth;
    private TextView txtPresentMonth;
    private MonthListAdapter adapter;
    private ArrayList<String> monthDays,allItemDate;

    private SimpleDateFormat sdf;
    private int longPosition, listTitlePosition;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_monthly_data, container, false);
        //getting views reference's
        monthListView = rootView.findViewById(R.id.listview_month);
        btnCurrentMonth = rootView.findViewById(R.id.btn_present_month);
        btnLastMonth = rootView.findViewById(R.id.btn_prev_month);
        txtPresentMonth = rootView.findViewById(R.id.txt_month);

        btnCurrentMonth.setEnabled(false);

        monthDays=new ArrayList();
        allItemDate=new ArrayList();

        // this takes current date
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_MONTH, 1);


        sdf = new SimpleDateFormat("dd'-'MMM'-'yyyy");//changing format of date

        txtPresentMonth.setText(""+sdf.format(c.getTime()));

        int monthMaxDays = c.getActualMaximum(Calendar.DAY_OF_MONTH);

        monthDays.clear();

        for (int i=0;i<monthMaxDays;i++){//getting current month dates

            monthDays.add(sdf.format(c.getTime()));
            c.add(Calendar.DAY_OF_WEEK, 1);
        }

        fillData();

        btnLastMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//to move previous month

                monthDays.clear();

                btnCurrentMonth.setEnabled(true);
                btnLastMonth.setEnabled(false);

                Calendar c = Calendar.getInstance();

                c.add(Calendar.MONTH, -1);

                c.set(Calendar.DATE, 1);

                sdf = new SimpleDateFormat("dd'-'MMM'-'yyyy");//changing format of date

                int monthMaxDays = c.getActualMaximum(Calendar.DAY_OF_MONTH);

                for (int i=0;i<monthMaxDays;i++){//getting previous week dates
                    monthDays.add(sdf.format(c.getTime()));
                    c.add(Calendar.DAY_OF_WEEK, 1);
                }

                fillData();
                txtPresentMonth.setText(""+monthDays.get(0));
            }
        });

        btnCurrentMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//to move current month

                monthDays.clear();

                btnCurrentMonth.setEnabled(false);
                btnLastMonth.setEnabled(true);

                Calendar c = Calendar.getInstance();
                c.set(Calendar.DAY_OF_MONTH, 1);

                int monthMaxDays = c.getActualMaximum(Calendar.DAY_OF_MONTH);

                monthDays.clear();

                for (int i=0;i<monthMaxDays;i++){

                    monthDays.add(sdf.format(c.getTime()));
                    c.add(Calendar.DAY_OF_WEEK, 1);
                }
                fillData();
                txtPresentMonth.setText(""+monthDays.get(0));

            }
        });

        //launching DataView activity on list item click
        monthListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                listTitlePosition = i;

                Intent intent = new Intent(getActivity(), DataViewActivity.class);
                intent.putExtra("title",allItemDate.get(i).toString());
                startActivity(intent);

            }
        });

        monthListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                longPosition = i;

                return false;
            }
        });
        return rootView;
    }


    //getting stored file's of shopping list
    private void fillData() {

        allItemDate.clear();

        File file = new File(Environment.getExternalStorageDirectory() +
                File.separator + "Shopping List" + File.separator + "Data");
        String arr[] = file.list();

        if (arr != null) {
            for (String i : arr) {
                if (i.endsWith(".txt")) {
                    String[] splitedShortDescription = i.split(".txt");
                    for (String date:monthDays){
                        if (splitedShortDescription[0].equals(date)){
                            // Setting data to the TextViews
                            allItemDate.add(splitedShortDescription[0]);
                        }
                    }
                }
            }
        }else {
            allItemDate.add("No data to display");
        }

        adapter=new MonthListAdapter();
        adapter.notifyDataSetChanged();

        monthListView.setAdapter(adapter);
    }

    //Adapter class contains listView data with custom list layout
    private class MonthListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return allItemDate.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {

            final LayoutInflater inflater= getActivity().getLayoutInflater();
            view=inflater.inflate(R.layout.swiping_tabs_data, null);

            adapter.notifyDataSetChanged();
            // Calling view references
            TextView titleTextView = view.findViewById(R.id.text_item);

            String title=allItemDate.get(position).toString();
            titleTextView.setText(title);

            //applying animation to display list items
            Animation anim = AnimationUtils.loadAnimation(getActivity(), R.anim.fly_in_from_top_corner);
            view.setAnimation(anim);
            anim.start();

            return view;
        }
    }

}
