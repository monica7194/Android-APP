package com.example.groceries.shoppinglist.adapters;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Data base class to store the given data
 */

public class ShoppingListDbAdapter {

    private static final int DATABASE_VERSION = 2;
    //Database name
    private static final String DATABASE_NAME = "shoppinglistdb";

    //Database table names
    private static final String DATABASE_CURRENT_TABLE="currentlistitems";
    private static final String DATABASE_FILTERED_LIST_TABLE="weeklistitems";

    //Current List table columns
    public static final String COL_CURRENT_ID = "rowno";
    public static final String COL_CURRENT_ITEM = "item";
    public static final String COL_CURRENT_QTY = "qty";
    public static final String COL_CURRENT_APX_PRICE = "apxprice";

    //Weekly List table columns
    public static final String COL_WEEK_ID = "col_id";
    public static final String COL_WEEK_ITEM = "itemname";
    public static final String COL_WEEK_QTY="qty";
    public static final String COL_WEEK_ITEM_PRICE = "price";
    public static final String COL_WEEK_DATE = "date";

    private static final String TAG = "ShoppingListDbAdapter";
    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    /**
     * Database TABLE creation sql statements
     */

    private static final String CREATE_TABLE_CURRENTLIST =
            "create table currentlistitems (rowno integer primary key autoincrement,item text not null," +
                    "qty text not null,apxprice text not null);";

    private static final String CREATE_TABLE_WEEKLYLIST =
            "create table weeklistitems (col_id integer primary key autoincrement,itemname text not null," +
                    "qty text not null,price text not null,date text not null);";

    private final Context mCtx;

    public ShoppingListDbAdapter(Context ctx) {
        this.mCtx = ctx;
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL(CREATE_TABLE_CURRENTLIST);
            db.execSQL(CREATE_TABLE_WEEKLYLIST);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");

            // on upgrade drop older tables
            db.execSQL("DROP TABLE IF EXISTS currentlistitems");
            db.execSQL("DROP TABLE IF EXISTS weeklistitems");

            // create new tables
            onCreate(db);
        }
    }



    public ShoppingListDbAdapter open() throws SQLException {
        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        mDbHelper.close();
    }

     /*=============  CURRENT SHOPPING LIST TABLE  ================ */

    //inserting record into data base
    public long insertCurrentItems(String item,String qty,String apxPrice) {

        ContentValues initialValues1 = new ContentValues();

        initialValues1.put(COL_CURRENT_ITEM,item);
        initialValues1.put(COL_CURRENT_QTY,qty);
        initialValues1.put(COL_CURRENT_APX_PRICE,apxPrice);

        return mDb.insert(DATABASE_CURRENT_TABLE, null, initialValues1);
    }

    //deleting a particular record based on row id
    public void deleteCurrentItem(String rowId) {

        mDb.delete(DATABASE_CURRENT_TABLE, COL_CURRENT_ID+"="+rowId, null);;
    }

    //getting all available records in database
    public Cursor getAllCurrentItems() {

        return mDb.query(DATABASE_CURRENT_TABLE, new String[] {COL_CURRENT_ID, COL_CURRENT_ITEM,
                        COL_CURRENT_QTY,COL_CURRENT_APX_PRICE}, null, null,
                null, null, null,null);
    }
    //getting one record data
    public Cursor fetchCurrentItem(String id) throws SQLException {

        return mDb.rawQuery("select * from "+DATABASE_CURRENT_TABLE+" where "
                +COL_CURRENT_ID+"="+id ,null);
    }
    //updating a record data
    public void updateCurrentItem(String rowId, String item,String qty,String apxPrice) {

        ContentValues args = new ContentValues();

        args.put(COL_CURRENT_ITEM, item);
        args.put(COL_CURRENT_QTY,qty);
        args.put(COL_CURRENT_APX_PRICE,apxPrice);

        //One more parameter is added for data
        mDb.update(DATABASE_CURRENT_TABLE, args, COL_CURRENT_ID + "=" + rowId, null);
    }

    /* =======  RECENT SHOPPING LIST TABLE  =========== */

    public long insertWeeklyItems(String items,String qty,String price,String date) {

        ContentValues initialValues = new ContentValues();

        initialValues.put(COL_WEEK_ITEM,items);
        initialValues.put(COL_WEEK_QTY,qty);
        initialValues.put(COL_WEEK_ITEM_PRICE,price);
        initialValues.put(COL_WEEK_DATE,date);

        return mDb.insert(DATABASE_FILTERED_LIST_TABLE, null, initialValues);
    }

    public void deleteWeeklyItem(String rowId) {

        mDb.delete(DATABASE_FILTERED_LIST_TABLE, COL_WEEK_ID+"="+rowId, null);
    }

    public void deleteWeeklyItems() {
        mDb.delete(DATABASE_FILTERED_LIST_TABLE, null, null);
    }

    public Cursor getWeeklyItems() {

        return mDb.query(DATABASE_FILTERED_LIST_TABLE,
                new String[] {COL_WEEK_ID, COL_WEEK_ITEM,COL_WEEK_QTY,COL_WEEK_ITEM_PRICE,COL_WEEK_DATE},
                null, null, null, null, null,null);
    }

    public Cursor getWeeklyItem(String rowId) throws SQLException {

        return mDb.rawQuery("select * from "+DATABASE_FILTERED_LIST_TABLE+" where "
                +COL_WEEK_ID+"="+rowId ,null);
    }

    public void modifyWeeklyItem(String id,String price) {

        ContentValues args = new ContentValues();

        args.put(COL_WEEK_ITEM_PRICE, price);

        //One more parameter is added for data
        mDb.update(DATABASE_FILTERED_LIST_TABLE, args, COL_WEEK_ID+ "=" + id,
                null);
    }
}
