package com.example.groceries.shoppinglist.fragments;

import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.groceries.shoppinglist.R;
import com.example.groceries.shoppinglist.adapters.ShoppingListDbAdapter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static android.graphics.Color.TRANSPARENT;

/**
 * Contains logic to add shopping list items,getting items from shopping list table,editing already
 * available item,removing item from list and adding items to recent list table
 * */

public class AddShoppingListFragment extends Fragment implements AdapterView.OnItemLongClickListener {

    private ListView listView;
    private Button buttonCompleteList;

    private ArrayList<String> itemsList,itemsQtyList,itemsApxPriceList,checkedItemsList,checkedQtyList,
            checkedItemPrice,unCheckedItemsList,unCheckedQty,unCheckedPrice,tempUnCheckedItems,
            tempUncCheckedQty,tempUnCheckedPrice;

    private ShoppingListDbAdapter dbAdapter;
    private Cursor cursor;

    private EditText edtItemName,edtQuantity,edtApproxPrice;
    private Spinner spinnerQtyType;
    private TextView textTotalPrice;

    private String weight="";
    private int position;
    private double price;

    private String[] weights={"kg","gr","pcs"};
    private ItemsListAdapter listAdapter;

    private String curDate;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //inflating fragment layout
        View rootView = inflater.inflate(R.layout.fragment_add_shopping_list, container, false);

        //getting references of fragment view's
        listView = rootView.findViewById(R.id.listview);
        buttonCompleteList = rootView.findViewById(R.id.btn_complete_list);
        edtItemName=rootView.findViewById(R.id.edittext_item_name);
        edtQuantity=rootView.findViewById(R.id.editText_qty);
        edtApproxPrice=rootView.findViewById(R.id.edt_apx_price);
        textTotalPrice=rootView.findViewById(R.id.textview_total_price);
        spinnerQtyType=rootView.findViewById(R.id.spinner_qty);

        Button btnAddItem = rootView.findViewById(R.id.btn_add_item);

        ArrayAdapter adapter=new ArrayAdapter(getContext(),android.R.layout.simple_spinner_item,weights);//adapter for spinner items
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerQtyType.setAdapter(adapter);//setting adapter to spinner

        dbAdapter = new ShoppingListDbAdapter(getActivity());//creating data base object
        dbAdapter.open();//opening data base to get writable data base
        cursor = dbAdapter.getAllCurrentItems();//getting all shopping list items

        //array list's for storing data
        itemsList = new ArrayList<>();
        itemsQtyList = new ArrayList<>();
        itemsApxPriceList=new ArrayList<>();

        checkedItemsList=new ArrayList<>();
        checkedQtyList=new ArrayList<>();
        checkedItemPrice=new ArrayList<>();

        unCheckedItemsList = new ArrayList<>();
        unCheckedQty=new ArrayList<>();
        unCheckedPrice=new ArrayList<>();

        long msTime = System.currentTimeMillis();
        Date curDateTime = new Date(msTime);//getting current day date

        SimpleDateFormat formatter = new SimpleDateFormat("dd'-'MMM'-'yyyy");//setting required format to date
        curDate = formatter.format(curDateTime);//applying date format to the current date

        if (cursor.getCount() != 0){//checking whether database having data or not,if contains data this block executes
            cursor.moveToFirst();//moving cursor to the first position
            updateListItems();//updating list items
        }

        listView.setOnItemLongClickListener(this);

        //spinner item click listener to choose weight type
        spinnerQtyType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                int position = spinnerQtyType.getSelectedItemPosition();
                weight=weights[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        edtItemName.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if(i== 66) {
                    //Clear focus here from edittext
                    edtQuantity.requestFocus();
                }

                return false;
            }
        });

        edtQuantity.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {

                if(i== EditorInfo.IME_ACTION_DONE) {
                    //Clear focus here from edittext
                    edtApproxPrice.requestFocus();
                }

                return false;
            }
        });

        price=0;

        edtApproxPrice.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if(i== EditorInfo.IME_ACTION_DONE) {
                    //Clear focus here from edittext
                    edtApproxPrice.clearFocus();
                    edtItemName.clearFocus();
                    edtQuantity.clearFocus();

                    InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
                }

                return false;
            }
        });

        btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//button event to add item to the shopping list(and shopping list table)

                //validating required data
                if(edtItemName.getText().toString().equals("")){
                    edtItemName.setError(getString(R.string.product_name));

                    return;
                }else if(edtQuantity.getText().toString().equals("")){
                    edtQuantity.setError(getString(R.string.product_quantity));

                    return;
                }else if(edtApproxPrice.getText().toString().equals("")){
                    edtApproxPrice.setText("00");
                }else {
                    dbAdapter.insertCurrentItems(edtItemName.getText().toString(),//inserting data into database
                            edtQuantity.getText().toString()+" "+weight,
                            edtApproxPrice.getText().toString());

                    //clearing edit text data
                    edtItemName.setText("");
                    edtQuantity.setText("");
                    edtApproxPrice.setText("");

                    edtApproxPrice.clearFocus();

                    InputMethodManager inputMethodManager =
                            (InputMethodManager) getActivity().getSystemService(Activity.INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(
                            getActivity().getCurrentFocus().getWindowToken(), 0);

                    listView.requestFocus();

                    updateListItems();//updating list to get latest data
                }
            }
        });

        buttonCompleteList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//to get bought items and add them to recent list table

                if (checkedItemsList.isEmpty()) {
                    toast(getString(R.string.empty_cart));
                } else {

                    tempUnCheckedItems = new ArrayList<>(unCheckedItemsList);
                    tempUncCheckedQty = new ArrayList<>(unCheckedQty);
                    tempUnCheckedPrice = new ArrayList<>(unCheckedPrice);

                    tempUnCheckedItems.removeAll(checkedItemsList);
                    tempUncCheckedQty.removeAll(checkedQtyList);
                    tempUnCheckedPrice.removeAll(checkedItemPrice);

                    cursor = dbAdapter.getWeeklyItems();

                    if (cursor.getCount() != 0) {
                        cursor.moveToFirst();
                        String date = cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_WEEK_DATE));

                        if (curDate.equals(date)) {
                            insertData();//calling to insert data into recent list table
                        } else {
                            //dialog to remove previously available items in the recent list data
                            //update dialog creation
                            final Dialog updateDialog = new Dialog(getActivity());
                            updateDialog.setTitle("Clear Recent List :");
                            updateDialog.setContentView(R.layout.delete_dialog);
                            updateDialog.show();

                            updateDialog.getWindow().setBackgroundDrawable(new ColorDrawable(TRANSPARENT));

                            //getting dialog button references
                            Button yesButton = updateDialog.findViewById(R.id.btn_yes);
                            Button noButton = updateDialog.findViewById(R.id.btn_no);

                            yesButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {//button to clear available recent list items
                                    dbAdapter.deleteWeeklyItems();

                                    insertData();
                                    updateDialog.dismiss();
                                }
                            });

                            noButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {//button to keep previous items and adding latest to existing list items
                                    insertData();
                                    updateDialog.dismiss();
                                }
                            });
                        }
                    } else {
                        insertData();
                    }
                }
            }
        });

        return rootView;
    }

    //Method to insert data into recent items table
    private void insertData(){
        for (int i=0;i<checkedItemsList.size();i++){

            String itemName=checkedItemsList.get(i);
            String itemQty=checkedQtyList.get(i);
            String itemPrice=checkedItemPrice.get(i);

            dbAdapter.insertWeeklyItems(itemName,itemQty,itemPrice,curDate);
            saveState(itemName,itemQty,itemPrice,curDate);//to save items as file in the storage
        }
        toast(getString(R.string.completed));
        updateListItems();
    }
    //custom toast creation
    private void toast(String msg){

        //Inflating Custom Toast Layout
        LayoutInflater inflaters =  getActivity().getLayoutInflater();
        View layout = inflaters.inflate(R.layout.toast_layout,
                (ViewGroup) getActivity().findViewById(R.id.toast_layout_root));

        TextView texts =  layout.findViewById(R.id.text);

        texts.setText(msg);
        Toast toast = new Toast(getContext());
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.show();
    }


    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        this.position = position;
        return false;
    }
//creating long click menu(context menu)
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getActivity().getMenuInflater().inflate(R.menu.context_menu_delete, menu);
    }

    @Override
    public boolean onContextItemSelected(final MenuItem item) {

        switch (item.getItemId()) {
            case R.id.context_remove://to remove item from list

                cursor.moveToPosition(position);
                String rowId = cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_CURRENT_ID));
                dbAdapter.deleteCurrentItem(rowId);
                listAdapter.notifyDataSetChanged();
                updateListItems();

                break;
            case R.id.context_edit://to edit or update item details

                cursor.moveToPosition(position);

                final String id = cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_CURRENT_ID));
                dbAdapter.fetchCurrentItem(id);

                final String iName = cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_CURRENT_ITEM));
                final String iQty = cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_CURRENT_QTY));
                final String iPrice = cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_CURRENT_APX_PRICE));

                //update dialog creation
                final Dialog updateDialog = new Dialog(getActivity());
                updateDialog.setTitle("Items List :");
                updateDialog.setContentView(R.layout.update_item_dialog);
                updateDialog.show();

                updateDialog.getWindow().setBackgroundDrawable(new ColorDrawable(TRANSPARENT));

                final EditText updateEdt = updateDialog.findViewById(R.id.edt_update_item);
                final EditText updateQty= updateDialog.findViewById(R.id.edt_update_qty);
                final EditText updatePrice=updateDialog.findViewById(R.id.edt_update_price);

                Button updateButton = updateDialog.findViewById(R.id.btn_update);
                Button cancelButton = updateDialog.findViewById(R.id.btn_cancel);

                updateEdt.setText(iName);
                updateQty.setText(iQty);
                updatePrice.setText(iPrice);

                updateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        dbAdapter.updateCurrentItem(id,updateEdt.getText().toString(),
                                updateQty.getText().toString(),updatePrice.getText().toString());

                        updateListItems();

                        listAdapter.notifyDataSetChanged();
                        updateDialog.dismiss();
                        toast(getString(R.string.item_updated));
                    }
                });

                cancelButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        updateDialog.dismiss();
                    }
                });

                break;

        }
        return super.onContextItemSelected(item);
    }
    //Method to get latest data
    private void updateListItems() {

        cursor = dbAdapter.getAllCurrentItems();
        itemsList.clear();
        itemsQtyList.clear();
        itemsApxPriceList.clear();

        price=0;

        for (int i = 0; i < cursor.getCount(); i++) {
            cursor.moveToPosition(i);
            itemsList.add(cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_CURRENT_ITEM)).trim());
            itemsQtyList.add(cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_CURRENT_QTY)).trim());
            itemsApxPriceList.add(cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_CURRENT_APX_PRICE)).trim());

            price=price+Double.parseDouble(cursor.getString(cursor.getColumnIndexOrThrow(ShoppingListDbAdapter.COL_CURRENT_APX_PRICE)));
        }

        if (!itemsList.isEmpty()) {
            buttonCompleteList.setEnabled(true);
            buttonCompleteList.setTextColor(Color.WHITE);
        } else {
            buttonCompleteList.setEnabled(false);
            buttonCompleteList.setTextColor(Color.GRAY);
        }

        listAdapter=new ItemsListAdapter();

        listAdapter.notifyDataSetChanged();//updating listView data set
        listView.setAdapter(listAdapter);//setting adapter to the listView

        textTotalPrice.setText("Total(~) : "+price);
    }

    //Adapter class contains listView data with custom list layout
    private class ItemsListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            // return the all items count
            return cursor.getCount();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            // Inflating custom layout to display items list
            View view = convertView;
            LayoutInflater inflater = getActivity().getLayoutInflater();
            view = inflater.inflate(R.layout.shopping_list_row, null);

            // Calling view references
            final TextView itemNameText = view.findViewById(R.id.textview_title);
            final TextView quantityText = view.findViewById(R.id.textview_qty);
            TextView apxPriceText = view.findViewById(R.id.textview_price);
            final CheckBox checkItem=view.findViewById(R.id.check_item);

            itemNameText.setText(itemsList.get(position));
            quantityText.setText(itemsQtyList.get(position));
            apxPriceText.setText("price: "+itemsApxPriceList.get(position));

            registerForContextMenu(itemNameText);

            if (!checkItem.isChecked()){
                unCheckedItemsList.add(itemsList.get(position));
                unCheckedQty.add(itemsQtyList.get(position));
                unCheckedPrice.add(itemsApxPriceList.get(position));
            }

            checkItem.setChecked(false);

            checkItem.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    if (checkItem.isChecked()){

                        checkedItemsList.add(itemsList.get(position));
                        checkedQtyList.add(itemsQtyList.get(position));
                        checkedItemPrice.add(itemsApxPriceList.get(position));

                        //to get strike effect on text
                        itemNameText.setPaintFlags(itemNameText.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                        quantityText.setPaintFlags(quantityText.getPaintFlags()|Paint.STRIKE_THRU_TEXT_FLAG);
                        itemNameText.setTextColor(Color.RED);
                        quantityText.setTextColor(Color.RED);

                    }else {
                        String unCheckString=itemsList.get(position);

                        checkedItemsList.remove(unCheckString);
                        checkedQtyList.remove(itemsQtyList.get(position));
                        checkedItemPrice.remove(itemsApxPriceList.get(position));

                        itemNameText.setPaintFlags(itemNameText.getPaintFlags() & (~ Paint.STRIKE_THRU_TEXT_FLAG));
                        quantityText.setPaintFlags(quantityText.getPaintFlags() & (~ Paint.STRIKE_THRU_TEXT_FLAG));
                        itemNameText.setTextColor(Color.WHITE);
                        quantityText.setTextColor(Color.WHITE);
                    }
                }
            });
            Animation anim = AnimationUtils.loadAnimation(getActivity(), R.anim.fly_in_from_top_corner);
            view.setAnimation(anim);
            anim.start();

            return view;
        }
    }
    //Saving bought items list as file in the storage
    private void saveState(String iName,String qty,String price,String titleDate) {

        String body = iName+"@t"+qty+"@s"+price+"@t";

        String fileName=titleDate;

        String text = body;

        try {
            File root = new File(Environment.getExternalStorageDirectory() +
                    File.separator + "Shopping List" + File.separator + "Data");
            if (!root.exists()) {
                root.mkdirs();
            }

            File gpxFile = new File(root, fileName+".txt");

            // if file doesn't exists, then create it
            if (!gpxFile.exists()) {
                gpxFile.createNewFile();

                FileWriter fw = new FileWriter(gpxFile.getAbsoluteFile(),true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(text);
                bw.close();
            }else {

                FileWriter writer = new FileWriter(gpxFile.getAbsoluteFile(),true);

                writer.write(text);

                writer.flush();
                writer.close();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}